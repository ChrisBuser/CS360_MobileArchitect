package com.zybooks.chrisbuserinventoryapp.repo;

import android.content.Context;

import androidx.room.Room;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.zybooks.chrisbuserinventoryapp.model.User;

public class UserRepository {

    private static UserRepository userRepo;
    private final UserDao userDao;

    // Singleton patters of UserRepository
    public static UserRepository getInstance(Context context)
    {
        if (userRepo == null)
        {
            userRepo = new UserRepository(context);
        }
        return userRepo;
    }

    private UserRepository(Context context)
    {
        UserDatabase database = Room.databaseBuilder(context, UserDatabase.class, "user.db")
                .allowMainThreadQueries()
                .build();

        userDao = database.userDao();
    }

    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            database.execSQL("ALTER TABLE user ADD COLUMN phoneNum TEXT");
        }
    };

    public void addUser(User user)
    {
        userDao.addUser(user);
    }

    public User getUser(String username)
    {
        return userDao.getUser(username);
    }

    public void deleteUser(User user)
    {
        userDao.deleteUser(user);
    }

    public void updateUser(User user)
    {
        userDao.updateUser(user);
    }
}
