package com.zybooks.chrisbuserinventoryapp.repo;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.zybooks.chrisbuserinventoryapp.model.Product;
import java.util.List;

@Dao
public interface ProductDao {
    @Query("SELECT * FROM Product WHERE sku = :sku")
    Product getProduct(long sku);

    @Query("SELECT * FROM Product ORDER BY sku COLLATE NOCASE")
    LiveData<List<Product>> getProducts();

    @Insert
    void addProduct(Product product);

    @Update
    void updateProduct(Product product);

    @Delete
    void deleteProduct(Product product);
}
