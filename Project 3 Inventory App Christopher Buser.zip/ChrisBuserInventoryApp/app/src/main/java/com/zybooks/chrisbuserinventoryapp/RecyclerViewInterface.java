package com.zybooks.chrisbuserinventoryapp;

interface RecyclerViewInterface {
    void onItemClick(int position);
}
