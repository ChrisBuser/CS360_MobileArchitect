package com.zybooks.chrisbuserinventoryapp.repo;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import com.zybooks.chrisbuserinventoryapp.model.Product;

@Database(entities = {Product.class}, version = 1)
public abstract class ProductDatabase extends RoomDatabase {
    public abstract ProductDao userDao();
}
