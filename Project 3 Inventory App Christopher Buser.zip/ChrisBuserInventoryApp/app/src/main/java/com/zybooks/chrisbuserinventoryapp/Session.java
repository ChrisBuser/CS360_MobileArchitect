package com.zybooks.chrisbuserinventoryapp;

import com.zybooks.chrisbuserinventoryapp.model.User;

// Class to store information in memory of
// user currently signed in
public class Session {
    private static User user;
    private static boolean signedIn = false;


    public void setUser(User userToSet)
    {
        user = userToSet;
    }

    public static User getUser()
    {
        return user;
    }

    public void setSignedIn(boolean isSignedIn)
    {
        signedIn = isSignedIn;
    }

    public boolean getSignedIn()
    {
        return signedIn;
    }

    public static void SignUserIn(User userToSignIn)
    {
        user = userToSignIn;
        signedIn = true;
    }

    public static void SignUserOut()
    {
        user = null;
        signedIn = false;
    }
}
