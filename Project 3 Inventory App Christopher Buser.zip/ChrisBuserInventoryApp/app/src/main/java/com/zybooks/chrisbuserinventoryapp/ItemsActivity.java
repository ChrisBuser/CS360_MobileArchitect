package com.zybooks.chrisbuserinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.zybooks.chrisbuserinventoryapp.model.Product;
import com.zybooks.chrisbuserinventoryapp.viewmodel.ProductViewModel;

import java.util.ArrayList;
import java.util.List;

public class ItemsActivity extends AppCompatActivity implements RecyclerViewInterface {

    //private FloatingActionButton addItemFab;
    FloatingActionButton addItemFab;
    //private RecyclerView recyclerView;
    ProductViewModel productViewModel;
    RecyclerView productRecyclerView;
    ProductAdapter productAdapter;
    List<Product> productsList;
    MaterialToolbar toolbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_items);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // set tool bar for the items activity
        toolbar = findViewById(R.id.items_activity_toolbar);
        setSupportActionBar(toolbar);

        addItemFab = findViewById(R.id.add_item_fab);

        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);

        productsList = new ArrayList<>();
        productAdapter = new ProductAdapter(productsList, this);

        productRecyclerView = findViewById(R.id.items_recycler_view);
        productRecyclerView.setAdapter(productAdapter);
        productRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        productViewModel.getProducts().observe(this, new Observer<List<Product>>() {
            @Override
            public void onChanged(List<Product> products) {
                productAdapter.setProducts(products);
                productAdapter.notifyDataSetChanged();
                productsList = products;
            }
        });
    }


    // set up menu in toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.items_activity_appbar_menu, menu);
        return true;
    }


    // called when menu item is clicked
    // navigates to account screen
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId() == R.id.account_icon)
        {
            Intent intent = new Intent(this, AccountActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    // onClick attribute of FAB
    public void AddNewProduct(View view)
    {
        Intent intent = new Intent(this, ItemEditActivity.class);
        startActivity(intent);
    }


    // called when item of recycler view is clicked
    // navigates to selected items details screen
    @Override
    public void onItemClick(int position)
    {
        Intent intent = new Intent(this, ItemDetailActivity.class);
        intent.putExtra("SKU", productsList.get(position).getSku());
        startActivity(intent);
    }
}