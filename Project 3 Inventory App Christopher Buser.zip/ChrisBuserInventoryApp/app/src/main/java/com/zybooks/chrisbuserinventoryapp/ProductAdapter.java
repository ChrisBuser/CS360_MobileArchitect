package com.zybooks.chrisbuserinventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.chrisbuserinventoryapp.model.Product;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder>{

    private final RecyclerViewInterface recyclerViewInterface;
    private List<Product> products;

    public ProductAdapter(List<Product> products, RecyclerViewInterface recyclerViewInterface)
    {
        this.products = products;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    public void setProducts(List<Product> products)
    {
        this.products = products;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_products_row, parent, false);

        ViewHolder viewHolder = new ViewHolder(view, recyclerViewInterface);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position)
    {
        Product product = products.get(position);

        holder.productNameTextView.setText(product.getName());
        holder.productSkuTextView.setText(String.valueOf(product.getSku()));
        holder.productInvTextView.setText(String.valueOf(product.getInventory()));
    }

    @Override
    public int getItemCount() {
        return products.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView productNameTextView;
        TextView productSkuTextView;
        TextView productInvTextView;
        //ImageView productImageView;
        ImageButton productDeleteButton;

        public ViewHolder(@NonNull View productView, RecyclerViewInterface recyclerViewInterface)
        {
            super(productView);
            productNameTextView = itemView.findViewById(R.id.row_product_name);
            productSkuTextView = itemView.findViewById(R.id.row_product_sku);
            productInvTextView = itemView.findViewById(R.id.row_product_inventory);
            //productImageView = itemView.findViewById(R.id.row_product_imageview);


            productView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (recyclerViewInterface != null)
                    {
                        int position = getAbsoluteAdapterPosition();

                        if (position != RecyclerView.NO_POSITION)
                        {
                            recyclerViewInterface.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}

