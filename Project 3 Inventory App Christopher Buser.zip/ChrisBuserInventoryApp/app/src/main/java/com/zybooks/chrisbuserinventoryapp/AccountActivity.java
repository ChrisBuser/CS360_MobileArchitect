package com.zybooks.chrisbuserinventoryapp;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import com.zybooks.chrisbuserinventoryapp.PermissionsUtil;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.zybooks.chrisbuserinventoryapp.model.User;
import com.zybooks.chrisbuserinventoryapp.viewmodel.UserViewModel;

public class AccountActivity extends AppCompatActivity {

    //SwitchCompat smsSwitch;
    MaterialToolbar toolbar;
    Button permissionButton;
    EditText phoneNumEditText;
    Activity accountActivity = this;
    UserViewModel userViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_account);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        userViewModel = new UserViewModel(getApplication());

        // set tool bar for the account activity
        toolbar = findViewById(R.id.account_activity_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // set widgets on screen
        phoneNumEditText = findViewById(R.id.phone_num_edit_text);
        permissionButton = findViewById(R.id.button);

        // set user's phone number in edit text if it is already saved
        if (Session.getUser() != null)
        {
            phoneNumEditText.setText(Session.getUser().getPhoneNum());
        }

        // disable permission button if already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            permissionButton.setText("Permission Granted");
            permissionButton.setEnabled(false);
        }
    }


    // set up menu in toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.account_activity_menu, menu);
        return true;
    }

    // called when menu item is clicked
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId() == R.id.Sign_out)
        {
            Session.SignUserOut();
            Intent intent = new Intent(this, UserAccountActivity.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }


    // save user's phone number in user.db
    public void SaveUserDetails(View view)
    {
        String phoneNum = phoneNumEditText.getText().toString();

        // input validation for phone number
        if (phoneNum.contains("+"))
        {
            if (phoneNum.length() == 12)
            {
                for (int i = 1; i < phoneNum.length(); i++) {
                    if (!Character.isDigit(phoneNum.charAt(i)))
                    {
                        Toast.makeText(AccountActivity.this, "Use + and numbers only", Toast.LENGTH_LONG).show();
                        return;
                    }
                }

                User user = Session.getUser();
                user.setPhoneNum(phoneNum);
                userViewModel.updateUser(user);
                Toast.makeText(AccountActivity.this, "Phone number saved", Toast.LENGTH_LONG).show();

            } else {
                Toast.makeText(AccountActivity.this, "Include country code\n" +
                        "and 10 digit number", Toast.LENGTH_LONG).show();
            }

        } else {
            Toast.makeText(AccountActivity.this, "Include + at start of number", Toast.LENGTH_LONG).show();
        }
    }


    // permission checks for sending SMS messages
    private final int REQUEST_SMS_CODE = 0;


    public void smsButtonClick(View view) {
        if (PermissionsUtil.hasPermissions(this, Manifest.permission.SEND_SMS, R.string.sms_rationale, REQUEST_SMS_CODE)) {
        }
    }


    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_SMS_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    smsButtonClick(null);
                }
            }
        }
    }
}