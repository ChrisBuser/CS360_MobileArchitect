package com.zybooks.chrisbuserinventoryapp.viewmodel;

import android.app.Application;

import com.zybooks.chrisbuserinventoryapp.model.User;
import com.zybooks.chrisbuserinventoryapp.repo.UserRepository;

public class UserViewModel {

    private UserRepository userRepo;

    public UserViewModel(Application application)
    {
        userRepo = UserRepository.getInstance(application.getApplicationContext());
    }

    public void addUser(User user)
    {
        userRepo.addUser(user);
    }

    public User getUser(String username)
    {
        return userRepo.getUser(username);
    }

    public void updateUser(User user)
    {
        userRepo.updateUser(user);
    }
}
