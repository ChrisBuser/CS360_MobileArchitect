package com.zybooks.chrisbuserinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.zybooks.chrisbuserinventoryapp.model.Product;
import com.zybooks.chrisbuserinventoryapp.viewmodel.ProductViewModel;

public class ItemDetailActivity extends AppCompatActivity {

    TextView productNameTextView;
    TextView productSkuTextView;
    TextView productCategoryTextView;
    TextView productLocationTextView;
    TextView productPriceTextView;
    TextView productCostTextView;
    TextView productMinInvTextView;
    TextView productInvTextView;
    ImageButton productEditButton;
    MaterialToolbar toolbar;
    private ProductViewModel productViewModel;
    private Product product;
    long sku;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        productViewModel = new ProductViewModel(getApplication());

        // set tool bar for the account activity
        toolbar = findViewById(R.id.item_detail_activity_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        sku = getIntent().getLongExtra("SKU", -1);
        product = productViewModel.getProduct(sku);

        // set widgets on screen
        productNameTextView = findViewById(R.id.product_detail_name_edit_text);
        productSkuTextView = findViewById(R.id.product_skunumber_text_view);
        productCategoryTextView = findViewById(R.id.product_category_text_view);
        productLocationTextView = findViewById(R.id.product_location_text_view);
        productPriceTextView = findViewById(R.id.product_price_text_view);
        productCostTextView = findViewById(R.id.product_cost_text_view);
        productMinInvTextView = findViewById(R.id.product_min_inventory_text_view);
        productInvTextView = findViewById(R.id.product_inventory_text_view);

        // set product values from database
        productNameTextView.setText(product.getName());
        productSkuTextView.setText(String.valueOf(product.getSku()));
        productCategoryTextView.setText(product.getCategory());
        productLocationTextView.setText(product.getLocation());
        productPriceTextView.setText(String.valueOf(product.getPrice()));
        productCostTextView.setText(String.valueOf(product.getCost()));
        productMinInvTextView.setText(String.valueOf(product.getMinInventory()));
        productInvTextView.setText(String.valueOf(product.getInventory()));
    }


    // navigate to edit item activity for current product
    public void EditItem()
    {
        Intent intent = new Intent(this, ItemEditActivity.class);
        intent.putExtra("SKU", sku);
        intent.putExtra("ORIGIN_ACTIVITY", "ItemDetailActivity");

        startActivity(intent);
    }


    // delete product from database and return items activity
    public void DeleteProduct()
    {
        productViewModel.deleteProduct(product);
        Toast.makeText(ItemDetailActivity.this, "Product Deleted", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, ItemsActivity.class);
        startActivity(intent);
    }


    // set up menu in toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.detail_item_activity_menu, menu);
        return true;
    }


    // called when menu item is clicked
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId() == R.id.edit_icon)
        {
            EditItem();
        }
        else if (item.getItemId() == R.id.delete_icon)
        {
            DeleteProduct();
        }
        return super.onOptionsItemSelected(item);
    }
}