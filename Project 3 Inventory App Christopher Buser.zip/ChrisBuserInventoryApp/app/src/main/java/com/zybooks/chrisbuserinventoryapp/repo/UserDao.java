package com.zybooks.chrisbuserinventoryapp.repo;

import androidx.room.*;
import androidx.room.Dao;
import com.zybooks.chrisbuserinventoryapp.model.User;

@Dao
public interface UserDao {
    @Query("SELECT * FROM User WHERE userName = :username")
    User getUser(String username);

    @Insert(onConflict = OnConflictStrategy.ABORT)
    void addUser(User user);

    @Delete
    void deleteUser(User user);

    @Update
    void updateUser(User user);
}
