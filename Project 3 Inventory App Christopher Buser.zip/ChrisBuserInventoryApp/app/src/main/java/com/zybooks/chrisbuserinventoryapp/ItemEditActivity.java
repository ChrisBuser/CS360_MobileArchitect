package com.zybooks.chrisbuserinventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.zybooks.chrisbuserinventoryapp.model.Product;
import com.zybooks.chrisbuserinventoryapp.viewmodel.ProductViewModel;

public class ItemEditActivity extends AppCompatActivity {

    EditText productNameEditText;
    TextView productSkuTextView;
    EditText productCategoryEditText;
    EditText productLocationEditText;
    EditText productPriceEditText;
    EditText productCostEditText;
    EditText productMinInvEditText;
    EditText productInvEditText;
    ImageButton inventoryEditButton;
    Button submitButton;
    MaterialToolbar toolbar;
    private ProductViewModel productViewModel;
    private String originActivity;
    private long sku;

    // local product variable for inserting and updating database
    private Product product;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item_edit);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // set widgets on screen
        productNameEditText = findViewById(R.id.product_detail_name_edit_text);
        productSkuTextView = findViewById(R.id.product_skunumber_textview);
        productCategoryEditText = findViewById(R.id.product_category_edit_text);
        productLocationEditText = findViewById(R.id.product_location_edit_text);
        productPriceEditText = findViewById(R.id.product_price_edit_text);
        productCostEditText = findViewById(R.id.product_cost_edit_text);
        productMinInvEditText = findViewById(R.id.product_min_inventory_edit_text);
        productInvEditText = findViewById(R.id.product_inventory_edit_text);

        // set tool bar for the account activity
        toolbar = findViewById(R.id.edit_product_toolbar);
        setSupportActionBar(toolbar);

        productViewModel = new ProductViewModel(getApplication());

        // determine which activity navigated from
        // set product values in edit text if exists
        // else blank edit texts for new item
        originActivity = getIntent().getStringExtra("ORIGIN_ACTIVITY");
        if (originActivity != null) {
            if (originActivity.equals("ItemDetailActivity")) {
                sku = getIntent().getLongExtra("SKU", -1);

                product = productViewModel.getProduct(sku);
                productNameEditText.setText(product.getName());
                productSkuTextView.setText(String.valueOf(product.getSku()));
                productCategoryEditText.setText(product.getCategory());
                productLocationEditText.setText(product.getLocation());
                productPriceEditText.setText(String.valueOf(product.getPrice()));
                productCostEditText.setText(String.valueOf(product.getCost()));
                productMinInvEditText.setText(String.valueOf(product.getMinInventory()));
                productInvEditText.setText(String.valueOf(product.getInventory()));
            }
        }
        else
        {
            product = new Product();
        }
    }


    // set up menu in toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.edit_item_activity_menu, menu);
        return true;
    }


    // called when menu item is clicked
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        if (item.getItemId() == R.id.save_icon)
        {
            SaveProductDetails(null);
        }
        return super.onOptionsItemSelected(item);
    }


    // call to save data from activity to database
    // calls either update or insert depending on if
    // product exists in database
    public void SaveProductDetails(View view)
    {
        // try to set variables on product object
        try {
            product.setName(productNameEditText.getText().toString());
            product.setCategory(productCategoryEditText.getText().toString());
            product.setLocation(productLocationEditText.getText().toString());
            product.setPrice(Float.parseFloat(productPriceEditText.getText().toString()));
            product.setCost(Float.parseFloat(productCostEditText.getText().toString()));
            product.setMinInventory(Integer.parseInt(productMinInvEditText.getText().toString()));
            product.setInventory(Integer.parseInt(productInvEditText.getText().toString()));
        } catch (NumberFormatException e) {
            Toast.makeText(ItemEditActivity.this, "Do not leave fields empty", Toast.LENGTH_LONG).show();
            return;
        } catch (Exception e) {
            Toast.makeText(ItemEditActivity.this, "Invalid Input", Toast.LENGTH_LONG).show();
            return;
        }

        // try to perform database operation
        // call to correct database operation (update or insert)
        try {

            // Update existing product
            if (originActivity != null) {
                if (originActivity.equals("ItemDetailActivity")) {
                    productViewModel.updateProduct(product);
                    Toast.makeText(ItemEditActivity.this, "Product Updated", Toast.LENGTH_LONG).show();

                    // product inventory is below minimum inventory amount
                    if (productViewModel.getProduct(product.getSku()).getInventory() <
                            productViewModel.getProduct(product.getSku()).getMinInventory())
                    {
                        Toast.makeText(ItemEditActivity.this, "Inventory getting low", Toast.LENGTH_LONG).show();

                        // try to send SMS message to user's saved number
                        try {
                            sendSMS();
                        } catch (Exception e) {
                            Toast.makeText(ItemEditActivity.this, "Unable to send "
                                    + "low \ninventory SMS message", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }

            // Insert new product
            else {
                productViewModel.addProduct(product);
                Toast.makeText(ItemEditActivity.this, "Product Added", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(ItemEditActivity.this, "Could not save to database", Toast.LENGTH_LONG).show();
        }

        // navigate to items activity
        Intent intent = new Intent(this, ItemsActivity.class);
        intent.putExtra("SKU", product.getSku());
        startActivity(intent);
    }


    // custom up button in tool bar
    // navigates to item detail activity if editing item
    // navigates to items activity if adding item
    public void BackButton(View view)
    {
        if (originActivity != null) {
            if (originActivity.equals("ItemDetailActivity")) {
                Intent intent = new Intent(this, ItemDetailActivity.class);
                intent.putExtra("SKU", sku);
                startActivity(intent);
            }
        }
        else
        {
            Intent intent = new Intent(this, ItemsActivity.class);
            startActivity(intent);
        }
    }


    // called when inventory below minimum inventory in SaveProductDetails() method
    // send text message to
    public void sendSMS()
    {
        // check user has saved phone number
        if (Session.getUser().getPhoneNum() != null) {
            SmsManager smsManager = SmsManager.getDefault();
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED)
            {
                smsManager.sendTextMessage(Session.getUser().getPhoneNum(), null,
                        "Item inventory getting low", null, null);
                Toast.makeText(ItemEditActivity.this, "SMS message sent", Toast.LENGTH_LONG).show();
            }
        }
    }
}