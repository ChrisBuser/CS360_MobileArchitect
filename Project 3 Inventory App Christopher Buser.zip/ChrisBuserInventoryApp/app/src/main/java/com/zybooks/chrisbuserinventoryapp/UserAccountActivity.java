package com.zybooks.chrisbuserinventoryapp;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zybooks.chrisbuserinventoryapp.model.User;
import com.zybooks.chrisbuserinventoryapp.viewmodel.UserViewModel;

public class UserAccountActivity extends AppCompatActivity {

    EditText usernameEditText;
    EditText passwordEditText;
    EditText firstNameEditText;
    EditText lastNameEditText;
    Button loginButton;
    Button createButton;
    View createAccount;
    TextView newUserTextView;
    TextView hideTextView;
    private boolean usernameEmpty;
    private boolean passwordEmpty;
    private UserViewModel userViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_account);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        userViewModel = new UserViewModel(getApplication());

        // define views of layout
        usernameEditText = findViewById(R.id.username_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);
        firstNameEditText = findViewById(R.id.first_name_edit_text);
        lastNameEditText = findViewById(R.id.last_name_edit_text);
        loginButton = findViewById(R.id.login_button);
        createButton = findViewById(R.id.create_account_button);
        createAccount = findViewById(R.id.create_account_fields_layout);
        newUserTextView = findViewById(R.id.new_user_text_view);
        hideTextView = findViewById(R.id.hide_text_view);

        // firstname and lastname views gone at start
        createAccount.setVisibility(GONE);

        // start app with both buttons disabled
        loginButton.setEnabled(false);
        createButton.setEnabled(false);

        // see if username edittext is empty
        usernameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ChangeLoginButtonEnabled();
                ChangeSignUpButtonEnabled();
            }
        });

        // see if password edittext is empty
        passwordEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ChangeLoginButtonEnabled();
                ChangeSignUpButtonEnabled();
            }
        });

        // see if first name edit text is empty
        firstNameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ChangeSignUpButtonEnabled();
            }
        });

        // see if last name edit text is empty
        lastNameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ChangeSignUpButtonEnabled();
            }
        });
    }


    // called in text changed listener of username and password edit texts
    // requires edit texts to be NOT empty to enable Login button
    void ChangeLoginButtonEnabled()
    {
        if ((usernameEditText.getText().toString().isEmpty() ||
                passwordEditText.getText().toString().isEmpty()) ||
                !firstNameEditText.getText().toString().isEmpty() ||
                !lastNameEditText.getText().toString().isEmpty())
        {
            loginButton.setEnabled(false);
        }
        else
        {
            loginButton.setEnabled(true);
        }
    }


    // called in text changed listener of all four edit texts
    // requires edit texts to be NOT empty to enable Create Account button
    void ChangeSignUpButtonEnabled()
    {
        if (firstNameEditText.getText().toString().isEmpty() ||
                lastNameEditText.getText().toString().isEmpty() ||
                usernameEditText.getText().toString().isEmpty() ||
                passwordEditText.getText().toString().isEmpty())
        {
            createButton.setEnabled(false);
        }
        else
        {
            createButton.setEnabled(true);
        }

    }


    // allows necessary edit texts to be visible to create an account
    // disables login button
    public void ExpandFields(View view)
    {
        createAccount.setVisibility(VISIBLE);
        loginButton.setEnabled(false);
        newUserTextView.setVisibility(GONE);
        hideTextView.setVisibility(VISIBLE);
        ChangeSignUpButtonEnabled();
    }


    // hides the first name and last name edit texts
    public void HideFields(View view)
    {
        firstNameEditText.setText("");
        lastNameEditText.setText("");
        createAccount.setVisibility(GONE);
        createButton.setEnabled(false);
        newUserTextView.setVisibility(VISIBLE);
        hideTextView.setVisibility(GONE);
        ChangeLoginButtonEnabled();
    }


    // onClick attribute of Create User button
    public void CreateUser(View createAccount)
    {
        // username already exists in user.db database
        if (null != userViewModel.getUser(usernameEditText.getText().toString()))
        {
            Toast.makeText(UserAccountActivity.this, "Username already exists", Toast.LENGTH_LONG).show();
        }
        else
        {
            User user = new User(
                    usernameEditText.getText().toString(),
                    passwordEditText.getText().toString(),
                    firstNameEditText.getText().toString(),
                    lastNameEditText.getText().toString());

            try {
                userViewModel.addUser(user);
            } catch (Exception e) {
                Toast.makeText(UserAccountActivity.this, "Could not save to database", Toast.LENGTH_LONG).show();
            }

            passwordEditText.setText("");
            firstNameEditText.setText("");
            lastNameEditText.setText("");
            HideFields(createAccount);
            Toast.makeText(UserAccountActivity.this, "Success! Login with your\n" +
                    "username and password", Toast.LENGTH_LONG).show();
        }
    }


    // onClick attribute of Login button
    public void LoginUser(View view)
    {
        User user = userViewModel.getUser(usernameEditText.getText().toString());

        // username exists in the user.db database
        if (null != user) {
            // password matches
            if (user.getPassword().equals(passwordEditText.getText().toString())) {
                Session.SignUserIn(user);
                Intent intent = new Intent(this, ItemsActivity.class);
                startActivity(intent);
                return;
            }
        }

        // either username or password is wrong
        Toast.makeText(UserAccountActivity.this, "username or password is incorrect", Toast.LENGTH_LONG).show();
    }
}