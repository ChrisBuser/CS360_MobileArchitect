package com.zybooks.chrisbuserinventoryapp.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.zybooks.chrisbuserinventoryapp.model.Product;
import com.zybooks.chrisbuserinventoryapp.repo.ProductRepository;

import java.util.List;

public class ProductViewModel extends AndroidViewModel {

    private ProductRepository productRepo;

    public ProductViewModel(Application application)
    {
        super(application);
        productRepo = ProductRepository.getInstance(application.getApplicationContext());
    }

    public void addProduct(Product product)
    {
        productRepo.addProduct(product);
    }

    public Product getProduct(long sku)
    {
        return productRepo.getProduct(sku);
    }

    public LiveData<List<Product>> getProducts()
    {
        return productRepo.getProducts();
    }

    public void updateProduct(Product product)
    {
        productRepo.updateProduct(product);
    }

    public void deleteProduct(Product product)
    {
        productRepo.deleteProduct(product);
    }
}
