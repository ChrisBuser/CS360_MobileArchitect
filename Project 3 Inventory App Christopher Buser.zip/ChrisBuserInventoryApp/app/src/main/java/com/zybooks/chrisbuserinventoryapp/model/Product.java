package com.zybooks.chrisbuserinventoryapp.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Product {

    @PrimaryKey(autoGenerate = true)
    private long sku;
    private String name;
    private String category;
    private String location;
    private float price;
    private float cost;
    private int minInventory;
    private int inventory;

    public Product() {}

    public Product(String name, String category, String location, float price, float cost, int minInventory, int inventory) {
        this.name = name;
        this.category = category;
        this.location = location;
        this.price = price;
        this.cost = cost;
        this.minInventory = minInventory;
        this.inventory = inventory;
    }

    // Getters and setters
    public long getSku() {
        return sku;
    }

    public void setSku(long sku) {
        this.sku = sku;
    }

    public String getName() {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getCategory()
    {
        return category;
    }

    public void setCategory(String category)
    {
        this.category = category;
    }

    public String getLocation()
    {
        return location;
    }

    public void setLocation(String location)
    {
        this.location = location;
    }

    public float getPrice()
    {
        return price;
    }

    public void setPrice(float price)
    {
        this.price = price;
    }

    public float getCost()
    {
        return cost;
    }

    public void setCost(float cost)
    {
        this.cost = cost;
    }

    public int getMinInventory()
    {
        return minInventory;
    }

    public void setMinInventory(int minInventory)
    {
        this.minInventory = minInventory;
    }

    public int getInventory()
    {
        return inventory;
    }

    public void setInventory(int inventory)
    {
        this.inventory = inventory;
    }
}
