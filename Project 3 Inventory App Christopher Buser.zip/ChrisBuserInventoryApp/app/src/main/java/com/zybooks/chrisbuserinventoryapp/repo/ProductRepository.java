package com.zybooks.chrisbuserinventoryapp.repo;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.room.Room;

import com.zybooks.chrisbuserinventoryapp.model.Product;

import java.util.List;

public class ProductRepository {

    private static ProductRepository productRepo;

    private final ProductDao productDao;

    // Singleton patters of ProductRepository
    public static ProductRepository getInstance(Context context)
    {
        if (productRepo == null)
        {
            productRepo = new ProductRepository(context);
        }
        return productRepo;
    }

    private ProductRepository(Context context)
    {
        ProductDatabase database = Room.databaseBuilder(context, ProductDatabase.class, "product.db")
                .allowMainThreadQueries()
                .build();

        productDao = database.userDao();
    }


    public void addProduct(Product product)
    {
        productDao.addProduct(product);
    }

    public Product getProduct(long sku)
    {
        return productDao.getProduct(sku);
    }

    public LiveData<List<Product>> getProducts()
    {
        return productDao.getProducts();
    }

    public void updateProduct(Product product)
    {
        productDao.updateProduct(product);
    }

    public void deleteProduct(Product product)
    {
        productDao.deleteProduct(product);
    }
}
